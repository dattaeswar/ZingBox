
import React from 'react';

interface HeaderProps {
  nowPlaying: string | null;
}

const Header: React.FC<HeaderProps> = ({ nowPlaying }) => {
  return (
    <header className="mb-8 text-center relative pt-4">
      <div className="absolute top-0 right-4 flex items-center gap-2">
        <div className="w-3 h-3 bg-red-600 rounded-full live-blink shadow-[0_0_10px_red]"></div>
        <span className="text-red-500 font-bold text-xs tracking-widest uppercase">Live Stage</span>
      </div>
      
      <h1 className="text-7xl font-outfit font-black tracking-tighter mb-4 italic text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]">
        ZING<span className="text-purple-500 underline decoration-4 underline-offset-8">BOX</span>
      </h1>
      
      <div className="h-14 flex items-center justify-center">
        {nowPlaying ? (
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-8 py-3 rounded-full border border-white/30 shadow-[0_0_30px_rgba(168,85,247,0.4)] animate-pulse">
            <span className="text-white font-black tracking-widest text-lg uppercase flex items-center gap-3">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
              {nowPlaying}
            </span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-1">
            <p className="text-purple-400 text-sm font-bold tracking-[0.3em] uppercase opacity-80">
              Pick up the sticks
            </p>
            <div className="w-12 h-1 bg-purple-900/50 rounded-full overflow-hidden">
               <div className="w-full h-full bg-purple-500 animate-[shimmer_2s_infinite]"></div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
