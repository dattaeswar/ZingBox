
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';

interface VibeCheckProps {
  history: string[];
}

const VibeCheck: React.FC<VibeCheckProps> = ({ history }) => {
  const [vibe, setVibe] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const checkVibe = async () => {
    if (history.length < 3) {
      setVibe("KEEP PLAYING...");
      return;
    }

    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `I just played these sounds on my drum pad: ${history.join(', ')}. 
                     In 10 words or less, tell me what kind of musical "vibe" I'm giving off. 
                     Be energetic, use producer slang, and shout it out like a DJ.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      setVibe(response.text.trim().toUpperCase());
    } catch (error) {
      console.error("Vibe check failed", error);
      setVibe("CROWD IS WAITING!");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full max-w-sm">
      {vibe && (
        <div className="bg-white/5 border border-white/10 px-6 py-3 rounded-2xl backdrop-blur-sm animate-in zoom-in duration-300">
          <p className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500 font-black text-center text-sm tracking-tight italic">
            "{vibe}"
          </p>
        </div>
      )}

      <button
        onClick={checkVibe}
        disabled={isLoading || history.length === 0}
        className={`
          group relative px-8 py-4 rounded-2xl font-black text-sm tracking-widest transition-all duration-200
          ${isLoading 
            ? 'bg-zinc-800 text-zinc-600 cursor-not-allowed' 
            : 'bg-white text-black hover:bg-yellow-400 hover:scale-105 active:scale-95'}
          shadow-[0_4px_0_rgba(0,0,0,0.2)]
        `}
      >
        <span className="flex items-center gap-3">
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-zinc-600 border-t-transparent rounded-full animate-spin" />
          ) : (
             <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
               <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 14.5c-2.49 0-4.5-2.01-4.5-4.5S9.51 7.5 12 7.5s4.5 2.01 4.5 4.5-2.01 4.5-4.5 4.5z"/>
             </svg>
          )}
          {isLoading ? 'ANALYZING BEAT' : 'CROWD FEEDBACK'}
        </span>
        
        {/* Button hover glow */}
        {!isLoading && (
          <div className="absolute inset-0 -z-10 bg-white/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
        )}
      </button>
    </div>
  );
};

export default VibeCheck;
