
import React, { useState } from 'react';
import { SoundPad } from '../types';

interface PadProps {
  pad: SoundPad;
  onPress: () => void;
  isActive: boolean;
}

const Pad: React.FC<PadProps> = ({ pad, onPress, isActive }) => {
  const [isPressing, setIsPressing] = useState(false);

  const handlePointerDown = () => {
    setIsPressing(true);
    onPress();
  };

  const handlePointerUp = () => {
    setIsPressing(false);
  };

  return (
    <div className="relative group">
      {/* Keyboard Trigger Indicator */}
      <div className="absolute -top-3 -right-2 z-20">
        <div className={`
          px-2 py-1 rounded-md border text-[10px] font-black tracking-widest
          transition-all duration-100 backdrop-blur-md
          ${(isPressing || isActive) 
            ? 'bg-white text-black border-white scale-110 shadow-[0_0_10px_white]' 
            : 'bg-black/50 text-stone-400 border-white/10 group-hover:border-white/30 group-hover:text-stone-200'}
        `}>
          {pad.keyHint}
        </div>
      </div>

      {/* Drum Sticks - Animated on Strike */}
      <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
        {isPressing && (
          <>
            {/* Left Stick */}
            <div 
              className="absolute w-32 h-3 bg-gradient-to-r from-stone-400 to-stone-200 rounded-full stick-anim-left origin-right border-r-4 border-stone-800"
              style={{ left: '-20%', top: '20%' }}
            />
            {/* Right Stick */}
            <div 
              className="absolute w-32 h-3 bg-gradient-to-l from-stone-400 to-stone-200 rounded-full stick-anim-right origin-left border-l-4 border-stone-800"
              style={{ right: '-20%', top: '20%' }}
            />
          </>
        )}
      </div>

      {/* The Pad Itself */}
      <button
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className={`
          relative aspect-square w-full rounded-3xl
          transition-all duration-75 ease-out outline-none
          flex items-center justify-center overflow-hidden
          ${isPressing || isActive ? 'scale-95 translate-y-2' : 'scale-100 hover:scale-[1.03] translate-y-0'}
        `}
        style={{ 
          backgroundColor: '#1a1a1e',
          border: `4px solid ${pad.color}`,
          boxShadow: isPressing || isActive 
            ? `0 0 0px ${pad.color}, inset 0 10px 20px rgba(0,0,0,0.8)` 
            : `0 15px 0 ${pad.color}44, 0 20px 40px rgba(0,0,0,0.5)`,
        }}
      >
        {/* Pad Core with Active Glow */}
        <div 
          className="absolute inset-2 rounded-[22px] flex items-center justify-center transition-opacity duration-100"
          style={{ 
            backgroundColor: (isPressing || isActive) ? pad.color : 'rgba(255,255,255,0.03)',
          }}
        >
          <span className={`
            font-black text-2xl md:text-3xl tracking-tighter transition-colors
            ${(isPressing || isActive) ? 'text-black' : 'text-stone-500 group-hover:text-stone-300'}
          `}>
            {pad.name}
          </span>
        </div>

        {/* Visual Feedback - Flash */}
        {(isPressing || isActive) && (
          <div className="absolute inset-0 bg-white/20 animate-pulse pointer-events-none" />
        )}
        
        {/* Rubber Texture Overlay */}
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(circle_at_center,_#fff_1px,_transparent_1px)] bg-[size:4px_4px]" />
      </button>
      
      {/* Pad Base (Shadow/3D Part) */}
      <div 
        className="absolute -bottom-2 left-0 right-0 h-8 -z-10 rounded-b-3xl"
        style={{ backgroundColor: `${pad.color}22` }}
      />
    </div>
  );
};

export default Pad;
